Leke Dada — Website Package
---------------------------
Files:
- index.html
- services.html
- portfolio.html
- pricing.html
- design-lab.html
- contact.html
- assets/style.css
- assets/*.png (design images)

How to use:
1. Upload the 'website_package' folder to your web host (public_html or www).
2. Ensure the 'assets' folder is in the same directory as the HTML files.
3. Replace contact email/phone in contact.html.
4. To enable real form submissions, replace the form action with your backend or Zapier/form backend.
5. Edit pages directly with any text editor.

Need help deploying? Reply and I can give step-by-step hosting instructions.