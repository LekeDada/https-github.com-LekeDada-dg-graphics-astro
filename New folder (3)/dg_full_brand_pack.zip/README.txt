DG Graphics Production — Full Brand & Website Pack
Includes:
- Multi-page website (index.html, services.html, portfolio.html, pricing.html, design-lab.html, contact.html)
- assets/ (styles.css, logo, mockups)
- social/ (social template images)
- print/ (business card HTML front/back)
- brand-guidelines.txt

How to use:
1. Unzip the package to your web host or local folder.
2. Open index.html in a browser to preview.
3. Replace the Formspree ID in contact.html or wire up your own backend.
4. For print-ready business cards, open print/business_card_front.html and back in a browser and print to PDF at 300 DPI.

Contact:
Leke Dada — Dgraphicsproduction@gmail.com • 832-289-5771